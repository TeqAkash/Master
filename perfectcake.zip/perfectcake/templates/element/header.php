<div class="wrapper row1">
    <header id="header" class="hoc clear">
      <div id="logo" class="fl_left"> 
        <!-- ################################################################################################ -->
        <h1 class="logoname"><a href="index.html">Dignostic<span>Hospital</span></a></h1>
        <!-- ################################################################################################ -->
      </div>
      <nav id="mainav" class="fl_right"> 
        <!-- ################################################################################################ -->
        <ul class="clear">
          <li class="active"><a href="/first">Home</a></li>
          <li><a class="drop" href="#">Patient Services / Appoint </a>
            <ul>
              <li><a href="/patients/add">New Patient </a></li>
              <li><a href="/appoints/add">Add Apointment</a></li>
              
              <li><a href="#">Visiting Address</a></li>
              <li><a href="/patients/logout">logout</a></li>
            </ul>
          </li>
          <li><a class="drop" href="#">Doctor Page</a>
           
          </li>
          <li><a href="#">Rating</a></li>
          <li><a href="#">Feedback</a></li>
          <li><a href="#">Suggestions</a></li>
        </ul>
        <!-- ################################################################################################ -->
      </nav>
    </header>
  </div>